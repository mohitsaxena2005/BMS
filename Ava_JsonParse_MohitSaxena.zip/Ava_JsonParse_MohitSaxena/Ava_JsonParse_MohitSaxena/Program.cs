﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;
using System.IO;

namespace Ava_JsonParse_MohitSaxena
{
    class Program
    {
        static void Main(string[] args)
        {
            //var model = JsonConvert.DeserializeObject(File.ReadAllText(@"Seller-Json.json"));
            JsonModel model = JsonConvert.DeserializeObject<JsonModel>(File.ReadAllText(@"Seller-Json.json"));

        }

        public static void PrintAddressLine1_Question2(Address address)
        {
            Console.WriteLine("Printing Address Line 1...");
            Console.WriteLine(address.addressLine1);
        }

        public static void PrintAllPhoneNumbers_Question3(Contact contact)
        {
            Console.WriteLine("Printing Phone Numbers...");

            foreach (var phoneNumber in contact.phoneNumbers)
            {
                Console.WriteLine("Phone Number ==>> " + phoneNumber);
            }
        }

        public static void PrintJurisdictionCount_Question4(Registrations registrations)
        {
            Console.WriteLine("Printing Jurisdriction count...");
            Console.WriteLine(registrations.jurisdictionISOCode.jurisdictionData.Count);   
        }

        public static void PrintAllJurisdictionValues_Question5(Registrations registrations)
        {
            foreach (var entry in registrations.jurisdictionISOCode.jurisdictionData)
            {
                
            }
        }

        public static  void ReplacVisaRegistrationDateForAllJurisdictionsAsTodaysDate_Question6()
        {
            
        }

        public static void CheckIfFileNameHaveHybridWordOrNot_Question7()
        {
            
        }

        public static void ReduceRegistrationDateByOneMonth_Question8()
        {

        }

        public static void PrintAmazonSellerKey(JsonModel model)
        {
            Console.WriteLine("Amazon Seller key is ...");
            Console.WriteLine(model.amazonSellerKey);
        }



    }
}
