﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace Ava_JsonParse_MohitSaxena
{
    public class JsonModel
    {
        public string name { get; set; }

        public Contact Contact { get; set; }
        public string businessType { get; set; }
        public Registrations registrations { get; set; }

        public DateTime createdDate { get; set; }
        public bool isTestSeller { get; set; }
        public string amazonSellerId { get; set; }
        public string amazonSellerKey { get; set; }

    }

    public class Contact
    {
        public string fullName { get; set; }
        public string attentionName { get; set; }
        public string companyName { get; set; }

        public Address address { get; set; }

        public string countryCode { get; set; }

        public List<int> phoneNumbers { get; set; }
        public string emailAddresses { get; set; }
    }

    public class Address
    {
        public string addressLine1 { get; set; }
        public string addressLine2 { get; set; }
        public string addressLine3 { get; set; }
        public string city { get; set; }
        public string stateOrRegion { get; set; }
        public string countyOrDistrict { get; set; }
        public string postalCode { get; set; }
        public string countryCode { get; set; }
        

    }

    public class Registrations
    {
        public JurisdictionISOCode jurisdictionISOCode { get; set; }
    }

    public class JurisdictionISOCode
    {
        public List<JurisdictionData> jurisdictionData { get; set; }
    }

    public class JurisdictionData
    {
        public string jurisdiction { get; set; }
        public string vatNumber { get; set; }
        public DateTime registrationDate { get; set; }
        public DateTime visaRegistrationDate { get; set; }
        public string staggerGroup { get; set; }
        public FilingFrequencies filingFrequencies { get; set; }

        public TaxOfficeDetails taxOfficeDetails { get; set; }

        public string activityCode { get; set; }
        public string periodStart { get; set; }
        public string periodEnd { get; set; }
        public bool isIntrastatDThresholdReached { get; set; }
        public bool isIntrastatAThresholdReached { get; set; }
        public bool isECLThresholdReached { get; set; }
        public bool isVISACountries { get; set; }
        public string taxID { get; set; }

        public int paymentInfoID { get; set; }
        public Login login { get; set; }
        public List<string> importRegime { get; set; }
        
    }

    public class Login
    {
        public string id { get; set; }
        public string password { get; set; }
    }

    public class FilingFrequencies
    {
        public int vatReturn { get; set; }
        public int? vatMonthlyPayment { get; set; }
        public int? ecl { get; set; }
        public int? intrastatAcquisitions { get; set; }
        public int? intrastatDispatches { get; set; }
    }

    public class TaxOfficeDetails
    {
        public string name { get; set; }

    }

    


}
